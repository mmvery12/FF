//
//  MainACT.cpp
//  FishingEat
//
//  Created by eisoo on 14-2-14.
//
//

#include "GameACT.h"
namespace Game
{
    Deletemultimap GameLayer::find()
    {
        Deletemultimap delmap;
        for (int row=0; row<7; row++) {
            std::string ss;
            
            for (int column=0; column<7; column++) {
                Node *node=this->getChildByTag(row*7+column);
                FruntCell *cell=dynamic_cast<FruntCell *>(node);
                char temps[2]="";
                
                if (this->cellsStatus[row][column]!=0||
                    node==NULL) {
                    std::sprintf(temps, "_");
                }else
                    std::sprintf(temps, "%u",cell->cellType);
                std::string sg(temps);
                ss+=sg;
                
            }
            ss+='_';
            char temp=NULL;
            int count=0;
            for (int i=0;i<ss.size();i++)
            {
                if (temp==ss[i]&&ss[i]!='_')
                {
                    count++;
                }else
                {
                    temp=ss[i];
                    if (count>=2)
                    {
                        count++;
                        int ff=i;
                        for (int column=0; column<count; column++) {
                            
                            ff--;
                            Node *node=this->getChildByTag(row*7+ff);
                            FruntCell *cell=dynamic_cast<FruntCell *>(node);
                            if (cell) {
                                delmap.insert(pair<int, int>(ff,row));
                                log("---> GameLayer : destory cell [%d][%d]",row,ff);
                            }
                        }
                    }
                    count=0;
                }
            }
        }
        
        
        for (int column=0; column<7; column++) {
            std::string ss;
            
            for (int row=0; row<7; row++) {
                Node *node=this->getChildByTag(row*7+column);
                FruntCell *cell=dynamic_cast<FruntCell *>(node);
                char temps[2]="";
                if (this->cellsStatus[row][column]!=0||
                    node==NULL) {
                    std::sprintf(temps, "_");
                }else
                    std::sprintf(temps, "%u",cell->cellType);
                std::string sg(temps);
                ss+=sg;
                
            }
            ss+='_';
            char temp=NULL;
            int count=0;
            for (int i=0;i<ss.size();i++)
            {
                if (temp==ss[i]&&ss[i]!='_')
                {
                    count++;
                }else
                {
                    temp=ss[i];
                    if (count>=2)
                    {
                        count++;
                        int ff=i;
                        for (int row=0; row<count; row++) {
                            ff--;
                            Node *node=this->getChildByTag(ff*7+column);
                            FruntCell *cell=dynamic_cast<FruntCell *>(node);
                            if (cell) {
                                //                                    cell->setCellStatus(cellDestory);
                                delmap.insert(pair<int, int>(column,ff));
                                
                                
                                
                                log("---> GameLayer : destory cell [%d][%d]",ff,column);
                            }
                        }
                    }
                    
                    count=0;
                }
            }
        }
        return delmap;
    }

    
    
    
    
    
    
    
    
    pthread_cond_t cond=PTHREAD_COND_INITIALIZER;
    pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
    bool flag = true;
    
    void *thr_fun(void *arge)
    {
        /*
        GameLayer *tempLay=(GameLayer *)arge;
        
        struct timeval now;
        struct timespec outtime;
        
        
        while (flag) {
            Log("thr_fun");
            
            
            gettimeofday(&now, NULL);
            outtime.tv_sec = now.tv_sec;
            outtime.tv_nsec = now.tv_usec+10000000;
            if (outtime.tv_nsec>=1000000000) {
                outtime.tv_sec+=1;
                outtime.tv_nsec=1000000000-outtime.tv_nsec;
            }
            pthread_mutex_lock(&mutex);
            pthread_cond_timedwait(&cond, &mutex, &outtime);
            pthread_mutex_unlock(&mutex);
            
        }
        */
        return NULL;
    }
    
    

    Scene *GameLayer::createGameACTScene(void)
    {
        Scene *pScene=Scene::create();
        pScene->addChild(GameLayer::create(), 0);
        return pScene;
    }
    void GameLayer::pop(Ref *node)
    {
//        SceneManager::popScene();
        
        for (int rowT=6; rowT>=0; rowT--) {
            char temps[10]="";
            char temps2[10]="";
            string temp;
            string temp2;
            for (int column=0; column<7; column++)
            {
                Node *node1=this->getChildByTag(rowT*7+column);
                FruntCell *cell=dynamic_cast<FruntCell *>(node1);
                int x=rowT;
                int y=column;
                if (cell!=NULL) {
                    sprintf(temps, "[%d][%d]%u ",x,y,cell->cellType);
                }else
                    sprintf(temps, "null    ");
                temp+=temps;
                
                sprintf(temps2, "%d ",cellsStatus[rowT][column]);
                temp2+=temp2;
            }
            log("%s",temp.c_str());
        }
        
        
        for (int rowT=6; rowT>=0; rowT--) {
            char temps2[10]="";
            string temp2;
            for (int column=0; column<7; column++)
            {
                sprintf(temps2, "%d ",cellsStatus[rowT][column]);
                temp2+=temps2;
            }
            log("%s",temp2.c_str());
        }
        
    }

	GameLayer::GameLayer()
	{
		cy=new Category;
	}
	GameLayer::~GameLayer()
	{
		delete cy;
	}

    bool GameLayer::init()
    {
        if (!Layer::init()) {
            return false;
        }
		_tempCell1=NULL;
		_tempCell2=NULL;
        srand(time(0));
        setTouchEnabled(true);
        
        
        Size size = Director::getInstance()->getWinSize();
        float winw = size.width;
        float winh = size.height;
        
        {//bg
            Sprite* pSprite = Sprite::create("bg-HD.png");
            pSprite->setPosition(Vec2(size.width/2, size.height/2));
            
            float spx = pSprite->getTextureRect().getMaxX();
            float spy = pSprite->getTextureRect().getMaxY();
            pSprite->setScaleX(winw/spx);
            pSprite->setScaleY(winh/spy);
            addChild(pSprite);
        }
        {
            Label *label1 = Label::createWithTTF("back", "fonts/Marker Felt.ttf", 45);
            MenuItemLabel *ccLabel1=MenuItemLabel::create(label1, CC_CALLBACK_1(GameLayer::pop, this));
            //create(label1, this, menu_selector(GameLayer::pop));
            Menu *menu=Menu::create(ccLabel1,NULL);
            menu->setPosition(Vec2(60, Director::getInstance()->getWinSize().height-120));
            this->addChild(menu);
        }
        {//progress
            Sprite *pgBg=Sprite::create("progress2-HD.png");
            pgBg->setPosition(Vec2(winw/2, winh-160));
            pgBg->setScaleX((winw/2)/pgBg->getTextureRect().getMaxX());
            addChild(pgBg);
            
            Sprite *pSp = Sprite::create("progress1-HD.png");
            progress = ProgressTimer::create(pSp);
            progress->setScaleX((winw/2)/pSp->getTextureRect().getMaxX());
            progress->setType(ProgressTimer::Type::BAR);
            progress->setPosition(winw/2, winh-160);
            progress->setPercentage(100);
            progress->setMidpoint(Vec2(0,1));
            progress->setBarChangeRate(Vec2(1,0));
            this->addChild(progress);
            dtf=100.0;
        }
        
        
        //make 7*7 cells
        for (int column=0; column<7; column++) {
            dropTopIndex[column]=6;
            for (int row=0; row<7; row++) {
                if (row<7) {
                    randNewCell(column, row,false);
                }
                cellsStatus[row][column]=0;
            }
        }
        
        DropList column1List;
        DropList column2List;
        DropList column3List;
        DropList column4List;
        DropList column5List;
        DropList column6List;
        DropList column7List;
        
        dropqdeque.push_back(column1List);
        dropqdeque.push_back(column2List);
        dropqdeque.push_back(column3List);
        dropqdeque.push_back(column4List);
        dropqdeque.push_back(column5List);
        dropqdeque.push_back(column6List);
        dropqdeque.push_back(column7List);
        
//        for (int i=0; i<7; i++) {
//            for (int j=0; j<7; j++) {
//                
//                cellsStatus[i][j]=0;
//            }
//        }
        
//        pthread_t findthr;
//        if (pthread_create(&findthr, NULL, thr_fun, (void *)this)) {
//            Log("create thread faile");
//            exit(-1);
//        }
        
        return true;
    }

    void GameLayer::onEnter()
    {
        Layer::onEnter();
		
        scheduleUpdate();
        //schedule(schedule_selector(GameLayer::update), 0.1, kCCRepeatForever, 0);
    }
    /*
    void GameLayer::registerWithTouchDispatcher(void)
    {
        Director *pDirector=Director::getInstance();
        pDirector->getTouchDispatcher()->addTargetedDelegate(this, 0, true);
    }
    */
    void GameLayer::clickAtInde(CellIndex index)
    {
        log("---> GameLayer : click at index column=%d row=%d tag=%d\r\n",index.columnPos,index.rowPos,index.rowPos*7+index.columnPos);
        _lastedClick=index;
    }
    
    void GameLayer::direction(MoveDirection dir)
    {
//        log("move direction %d",dir);
        compute(dir);
    }
    
    void GameLayer::compute(MoveDirection dir)
    {
        CellIndex _tempIndex=_lastedClick;
        bool flag=false;
        if (dir==DOWN) {
            _tempIndex.rowPos-=1;
            flag=_tempIndex.rowPos<0?false:true;
            //若_lasted正上方存在则移动
        }
        if (dir==UP) {
            _tempIndex.rowPos+=1;
            flag=_tempIndex.rowPos>6?false:true;
            //若_lasted正下方存在则移动
        }
        if (dir==LEFT) {
            _tempIndex.columnPos-=1;
            flag=_tempIndex.columnPos<0?false:true;
            //若_lasted正左方存在则移动
        }
        if (dir==RIGHT) {
            _tempIndex.columnPos+=1;
            flag=_tempIndex.columnPos>6?false:true;
            //若_lasted正右方存在则移动
        }
        if (flag) {
            registTwoCell(_lastedClick, _tempIndex);
        }
    }
    
    /*!
     click callback
     change cellStatus
     */
    void GameLayer::shouldmoving(Layer *cell)
    {
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=1;
    }
    
    void GameLayer::moving(Layer *cell)
    {
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=2;
    }
    void GameLayer::deleteing(Layer *cell)
    {
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=4;
    }
    void GameLayer::droping(Layer *cell)
    {
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=3;
        
    }
    
    
    void GameLayer::movingComplete(Layer *cell)
    {
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=0;
    }
    
    void GameLayer::deleteComplete(Layer *cell)
    {
//        pthread_mutex_lock(&mutex);
    
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=-1;
        CellIndex index=temp->nowIndex;
        if (cell==_tempCell1) {
            _tempCell1=NULL;
        }
        if (cell==_tempCell2) {
            _tempCell2=NULL;
        }
        this->removeChild(cell);
        
        int rowPos=index.rowPos;
        int columnPos=index.columnPos;
        
        DropList list=dropqdeque.at(columnPos);
        ListIterator listit=list.begin();
        DropMap map=*listit;
        MapIterator mapit=map.begin();
        _MAX_ROW row=mapit->first;
        if (rowPos==row) {
            DropSubMap submap=mapit->second;
            TODO_dropCell(submap,columnPos);
            map.erase(mapit);
        }
        
//        pthread_mutex_unlock(&mutex);
    }
    
    void GameLayer::dropComplete(Layer *cell)
    {
        FruntCell *temp=dynamic_cast<FruntCell *>(cell);
        cellsStatus[temp->getCellIndex().rowPos][temp->getCellIndex().columnPos]=0;
        dropTopIndex[temp->getCellIndex().columnPos]--;
    }
    
    
    void GameLayer::timeCallBack()
    {
        TODO_deleteCell();
        TODO_resetCell();
    }
    

    
    
    void GameLayer::TODO_deleteCell()
    {
        Deletemultimap delmap=find();
        if (delmap.empty()) {
            return;
        }
        
        
        for (int column=0; column<7; column++) {
            if (delmap.count(column)==0) {
                continue;
            }
            
            pair<DeleteIterator,DeleteIterator> Findpair=delmap.equal_range(column);
            DeleteIterator dit=Findpair.first;
            
            Deletemultimap temp;
            for (; dit->first!=Findpair.second->first;dit++) {
                temp.insert(pair<int, int>(dit->first,dit->second));
            }
            
            vector<PAIR> name_score_vec(temp.begin(), temp.end());
            sort(name_score_vec.begin(), name_score_vec.end(), CmpByValue());
            vector<PAIR>::iterator vecIt=name_score_vec.begin();
            
            temp.erase(column);
            for (; vecIt!=name_score_vec.end(); vecIt++) {
                temp.insert(*vecIt);
            }
            
            DeleteIterator delit=temp.begin();
            
            
            DropList *slist=&dropqdeque.at(column);
            DropMap map;
            _MAX_ROW max=delit->second;
            int addCount=delmap.count(column);
            
            for (int i=0; i<addCount; i++) {
                dropTopIndex[column]++;
                log("---> GameLayer : column [%d] top  index %d",column,dropTopIndex[column]);
                randNewCell(column, dropTopIndex[column], true);
                log("---> GameLayer : add new cell at column %d row %d",column,dropTopIndex[column]);
            }
            
            int existTop=dropTopIndex[column];
            int existBottom=0;

            bool lastedStatus=false;
            bool nowStatus=false;
            
            for (int i=dropTopIndex[column]; i>=0&&delit!=temp.end(); i--) {
				
                int row=delit->second;
                
                //exist
                if (row!=i) {
                    if (lastedStatus==false) {
                        existTop=i;
                    }
                    existBottom=i;
                    nowStatus=true;
                }
                //no exist
                if (row==i) {
                    delit++;
                    nowStatus=false;
                }
                
                if (lastedStatus==true&&nowStatus==false) {
                    DropRange range;
                    range.insert(pair<int, int>(existTop,existBottom));
                    DropSubMap submap;
                    submap.insert(pair<DropRange, int>(range,addCount));
                    map.insert(pair<int, DropSubMap>(max,submap));
                    
                    log("---> GameLayer : range beginrow %d -endrow %d drop %d",existTop,existBottom,addCount);
                }
                
                
                
                if (row!=i) {
                    lastedStatus=true;
                }
                if (row==i) {
                    addCount--;
                    lastedStatus=false;
                }
            }
            
            
            
            
            

            

            slist->push_back(map);
            delit=temp.begin();
			for (;delit!=temp.end();delit++)
			{
				
				CellIndex temp;
				temp.rowPos=delit->second;
				temp.columnPos=column;

				Node *node1=this->getChildByTag(temp.rowPos*7+temp.columnPos);
				if (node1) {
					FruntCell *cell1=dynamic_cast<FruntCell *>(node1);
					cell1->setAnimationContig(DeleteAnimation, temp);
					cell1->setCellStatus(cellDestory);
				}
			}
			

 //            recuse(it, &map, Findpair, addCount+6);           
            /*
            int MAX_ROW=-1;
            int MIN_ROW=-1;
            int DROP_LENGTH=-1;
            int DROP_COLUMN=-1;
            MIN_ROW=it->second;
            for (; it!=Findpair.second; ++it)
            {
                int rowTemp=it->second;
                
                if (rowTemp<=MIN_ROW) {
                    MIN_ROW=rowTemp;
                }
                if (rowTemp>=MAX_ROW) {
                    MAX_ROW=rowTemp;
                }
            }
            DROP_COLUMN=column;
            DROP_LENGTH=MAX_ROW-MIN_ROW+1;
            
            DropQueue dorpqueue=dropoperation.at(column);
            DropLength droplength;
            DropMap dropmap;
            droplength.insert(pair<int, int>(MAX_ROW,DROP_LENGTH));
            dropmap.insert(pair<int, DropLength>(DROP_COLUMN,droplength));
            dorpqueue.push_back(dropmap);
            
            //->>>>>>>set cell delete
            CellIndex temp;
            temp.rowPos=it->second;
            temp.columnPos=it->first;
            
            Node *node1=this->getChildByTag(temp.rowPos*7+temp.columnPos);
            if (node1) {
                FruntCell *cell1=dynamic_cast<FruntCell *>(node1);
                cell1->setAnimationContig(DeleteAnimation, temp);
                cell1->setCellStatus(cellDestory);
            }
            */
        }
        Dropdeque qu=this->dropqdeque;
        
    }
    void GameLayer::TODO_resetCell()
    {
        if (_tempCell1==NULL||_tempCell2==NULL) {
            _tempCell1=NULL;
            _tempCell2=NULL;
        }else
            if (_tempCell1!=NULL&&_tempCell2!=NULL&&
                _tempCell1->_isMoving==false&&
                _tempCell2->_isMoving==false&&
                cellsStatus[_tempCell1->nowIndex.rowPos][_tempCell1->nowIndex.columnPos]==0&&
                cellsStatus[_tempCell2->nowIndex.rowPos][_tempCell2->nowIndex.columnPos]==0) {
                _tempCell1->setAnimationContig(OnlyMoveAnimation, _tempCell1->toIndex);
                _tempCell2->setAnimationContig(OnlyMoveAnimation, _tempCell2->toIndex);
                _tempCell1=NULL;
                _tempCell2=NULL;
            }
    }
    void GameLayer::TODO_dropCell(DropSubMap submap,int column)
    {
        SubMapIterator subIt=submap.begin();
        for (; subIt!=submap.end(); subIt++) {
            DropRange range=subIt->first;
            _DROPLENGTH step=subIt->second;
            RangeIterator rangeIt=range.begin();
            _BEGIN_ROW begin=rangeIt->first;
            _END_ROW end=rangeIt->second;
            for (int row=end; row<=begin; row++) {
                Node *node=this->getChildByTag(row*7+column);
                FruntCell *cell=dynamic_cast<FruntCell *>(node);
                if (cell) {
                    CellIndex temp=cell->getCellIndex();
                    int originRow=temp.rowPos;
                    temp.rowPos-=step;
                    log("---> GameLayer : cell [%d][%d] drop to [%d][%d]",originRow,temp.columnPos,temp.rowPos,temp.columnPos);
                    cell->setAnimationContig(DropAnimation, temp);
                }
            }
        }
        
        
        
       
        
//        droplengthIterator=droplength.begin();
//        int MAX_row=droplengthIterator->first;
//        int
//        
//        dropqueueiterator=dropqueue.begin();
//        int index=*dropqueueiterator;
//        for (int column=0; column<7; column++) {
//            for (int i=index+1; i<13-index; i++) {
//                Node *node=this->getChildByTag(index*7+column);
//                FruntCell *cell=dynamic_cast<FruntCell *>(node);
//            }
//        }
//        
//        
//        dropqueue.pop_front();
        /*
        for (int column=0; column<7; column++) {
            for (int row=0; row<7; row++) {
                int count=0;
                for (int index=row; index<14; index++) {
                    Node *node=this->getChildByTag(index*7+column);
                    FruntCell *cell=dynamic_cast<FruntCell *>(node);
                    if (cellsStatus[index][column]==-1||
                        cellsStatus[index][column]==1||
                        cellsStatus[index][column]==3) {
                        
                        count++;
                        if (cellsStatus[index][column]==3) {
                            count=cell->toIndex.rowPos;
                        }
                    }else if(node!=NULL)
                    {
                        CellIndex temp;
                        if (cellsStatus[index][column]==3) {
                            temp.rowPos=count+1;
                        }else
                            temp.rowPos=index-count;
                        temp.columnPos=column;
                        if (!cell->isCellIndexEqual(temp, cell->nowIndex)) {
                            cell->setAnimationContig(DropAnimation, temp);
                            Log("---> GameLayer : drop cell at index[%d][%d] to index[%d][%d]",cell->getCellIndex().rowPos,cell->getCellIndex().columnPos,index-count,column);
                        }
                        
                        break;
                    }
                }
            }
        }
         */
    }
    
    
    void GameLayer::showTag()
    {
        for (int row=0; row<7; row++) {
            log("-------->");
            log("%d %d %d %d %d %d %d",cellsStatus[row][0],cellsStatus[row][1],cellsStatus[row][2],cellsStatus[row][3],cellsStatus[row][4],cellsStatus[row][5],cellsStatus[row][6]);
            log("<--------");
        }
    }
    
//    void GameLayer::showCellAnimation()
//    {
//        for (int i=0; i<14; i++) {
//            for (int j=0; j<7; j++) {
//                Node *node=NULL;
//                FruntCell *cell=NULL;
//                node=getChildByTag(i*7+j);
//                cell=dynamic_cast<FruntCell *>(node);
//                if (cell!=NULL&&cell->_isMoving==false&&cellsStatus[i][j]==1){
//                    cell->showAnimation();
//                    switch (cell->animationtype) {
//                        case OnlyMoveAnimation:
//                            log("animation MoveAnimation [%d][%d] ",i,j);
//                            break;
//                        case DeleteAnimation:
//                            log("animation DeleteAnimation [%d][%d] ",i,j);
//                            break;
//                        case DropAnimation:
//                            log("animation DropAnimation [%d][%d] ",i,j);
//                            break;
//                        default:
//                            break;
//                    }
//                    
//                }
//            }
//        }
//    }
    
    void GameLayer::checkColumnHaveAnimation()
    {
        for (int column=0; column<7; column++) {
            animationColumns[column]=0;
            for (int row=0; row<7; row++) {
                if (cellsStatus[row][column]==3) {
                    animationColumns[column]=1;
                    break;
                }
            }
        }
    }
    void GameLayer::registTwoCell(CellIndex c1, CellIndex c2)
    {
        _tempCell1=NULL;
        _tempCell2=NULL;
        Node *node1=this->getChildByTag(c1.rowPos*7+c1.columnPos);
        Node *node2=this->getChildByTag(c2.rowPos*7+c2.columnPos);
        FruntCell *cell1=dynamic_cast<FruntCell *>(node1);
        FruntCell *cell2=dynamic_cast<FruntCell *>(node2);
        if (node1!=NULL&&node2!=NULL) {
            _tempCell1=cell1;
			_tempCell2=cell2;
            cell1->setAnimationContig(OnlyMoveAnimation, c2);
            cell2->setAnimationContig(OnlyMoveAnimation, c1);
        }
    }
    void GameLayer::resetTwoCellPos()
    {
        
        
        
    }
    void GameLayer::destory()
    {
        for (int column=0; column<7;column++) {
            int count=0;
            bool haveD=false;
            for (int row=0; row<7; row++) {
                Node *node=this->getChildByTag(row*7+column);
                FruntCell *cell=dynamic_cast<FruntCell *>(node);
                if (cell&&
                    cell->getCellStatus()==cellDestory&&
                    cellsStatus[row][column]==-1) {
                    if (cell==_tempCell1) {
                        _tempCell1=NULL;
                    }
                    if (cell==_tempCell2) {
                        _tempCell2=NULL;
                    }
                    this->removeChild(cell);
                    log("---> GameLayer : cell [%d][%d] delete",row,column);
                    count++;
                    dropTopIndex[column]++;
                    haveD=true;
                }
            }
            
            if (haveD) {
                
                addNewCells(column);
            }
        }
    }
    
   
    void GameLayer::addNewCells(int column)
    {
        
        
        
        
        for (int row=0; row<7; row++) {
            int count=0;
            for (int index=row; index<14; index++) {
                Node *node=this->getChildByTag(index*7+column);
                FruntCell *cell=dynamic_cast<FruntCell *>(node);
                if (cellsStatus[index][column]==-1||
                    cellsStatus[index][column]==1||
                    cellsStatus[index][column]==3) {
                    
                    count++;
                    if (cellsStatus[index][column]==3) {
                        count=cell->toIndex.rowPos;
                    }
                }else if(node!=NULL)
                {
                    CellIndex temp;
                    if (cellsStatus[index][column]==3) {
                        temp.rowPos=count+1;
                    }else
                        temp.rowPos=index-count;
                    temp.columnPos=column;
                    if (!cell->isCellIndexEqual(temp, cell->nowIndex)) {
                        cell->setAnimationContig(DropAnimation, temp);
                        log("---> GameLayer : drop cell at index[%d][%d] to index[%d][%d]",cell->getCellIndex().rowPos,cell->getCellIndex().columnPos,index-count,column);
                    }

                    break;
                }
            }
        }
    }
    
    void GameLayer::update(float dt)
    {
        
        float ct1 = progress->getPercentage();
        
        if (ct1 != 0)
        {
            dtf = ct1 - 0.1f;
            progress->setPercentage(dtf);
        }
        else
        {
            //            TransitionFade *tScene = TransitionFade::create(2, HelloWorld::scene(), ccWHITE);
            //            Director::sharedDirector()->replaceScene(tScene);
        }
        timeCallBack();
    }
    
    
    FruntCell * GameLayer::randNewCell(int column,int row,bool isPlaying)
    {
        FruntCell *_fs=FruntCell::create();
        double width=Director::getInstance()->getWinSize().height/7;
        _fs->setContentSize(Size(width, width));
        double _cloumnPos=width*(column%7);
        double _rowPos;
        if (isPlaying) {
            _rowPos=Director::getInstance()->getWinSize().height;
        }else
            _rowPos=width*row;
        _fs->setPosition(Vec2(_cloumnPos, _rowPos));
        this->addChild(_fs);
        _fs->setNowIndex(row, column);
        _fs->registDelegate(this);
        cellsStatus[row][column]=0;
        return _fs;
    }
    
    
    bool GameLayer::onTouchBegan(Touch *pTouch, Event *pEvent)
    {
        log("---> GameLayer : game layer click");
        return true;
    }
    void GameLayer::onTouchMoved(Touch *pTouch, Event *pEvent)
    {
        
    }
    
    void GameLayer::onTouchEnded(Touch *pTouch, Event *pEvent)
    {
        
    }
    
    
    
}
