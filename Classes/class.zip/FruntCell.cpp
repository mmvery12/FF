//
//  FruntCell.cpp
//  FruitEat
//
//  Created by eisoo on 14-3-31.
//
//

#include "FruntCell.h"
/*
 frunt class implementation
 
 */
/*
void FruntCell::setIndex(int column,int row)
{
    _index.columnPos=column;
    _index.rowPos=row;
    setTag(row*7+column);
}
void FruntCell::setTempIndex(int column,int row)
{
    _tempIndex.columnPos=column;
    _index.rowPos=row;
}

void FruntCell::movingComplete()
{
    _isMoving=false;
    setIndex(_movingIndex.columnPos, _movingIndex.rowPos);
    _layer->movingComplete((CCLayer *)this);
}

void FruntCell::exchangeComplete()
{
    _isMoving=false;
    setIndex(_movingIndex.columnPos, _movingIndex.rowPos);
    _layer->exchangeComplete((CCLayer *)this);
}
void FruntCell::deleteComplete()
{
    _isMoving=false;
    _layer->deleteComplete((CCLayer *)this);
}
void FruntCell::dropComplete()
{
    _isMoving=false;
    setIndex(_movingIndex.columnPos, _movingIndex.rowPos);
    _layer->dropComplete((CCLayer *)this);
}


void FruntCell::setMoveToIndex(int column,int row)
{
    if (column==_index.columnPos&&row==_index.rowPos) {
        return;
    }
    _tempIndex.columnPos=_index.columnPos;
    _tempIndex.rowPos=_index.rowPos;
    _isMoving=true;
    _layer->moving((CCLayer *)this);
    _movingIndex.columnPos=column;
    _movingIndex.rowPos=row;
    double width=CCDirector::sharedDirector()->getWinSize().width/7;
    double _cloumnPos=width*(column%7);
    double _rowPos=width*row;
    
    CCFiniteTimeAction *act2=CCMoveTo::create(0.15, ccp(_cloumnPos, _rowPos));
    CCActionInstant *act3=CCCallFunc::create(this, callfunc_selector(FruntCell::movingComplete));
    CCSequence *actList=CCSequence::create(act2,act3,NULL);
    runAction(actList);
}

void FruntCell::setDropToIndex(int column,int row)
{
    if (column==_index.columnPos&&row==_index.rowPos) {
        return;
    }
    _tempIndex.columnPos=_index.columnPos;
    _tempIndex.rowPos=_index.rowPos;
    _isMoving=true;
    _layer->droping(this);
    _movingIndex.columnPos=column;
    _movingIndex.rowPos=row;
    double width=CCDirector::sharedDirector()->getWinSize().width/7;
    double _cloumnPos=width*(column%7);
    double _rowPos=width*row;
    
    CCFiniteTimeAction *act2=CCMoveTo::create(0.15, ccp(_cloumnPos, _rowPos));
    CCActionInstant *act3=CCCallFunc::create(this, callfunc_selector(FruntCell::dropComplete));
    CCSequence *actList=CCSequence::create(act2,act3,NULL);
    runAction(actList);
}

void FruntCell::resetMoveToIndex()
{
    _isMoving=true;
    _layer->moving(this);
    _movingIndex.columnPos=_tempIndex.columnPos;
    _movingIndex.rowPos=_tempIndex.rowPos;
    int column= _movingIndex.columnPos;
    int row= _movingIndex.rowPos;
    double width=CCDirector::sharedDirector()->getWinSize().width/7;
    double _cloumnPos=width*(column%7);
    double _rowPos=width*row;
    CCFiniteTimeAction *act2=CCMoveTo::create(0.15, ccp(_cloumnPos, _rowPos));
    CCActionInstant *act3=CCCallFunc::create(this, callfunc_selector(FruntCell::exchangeComplete));
    CCSequence *actList=CCSequence::create(act2,act3,NULL);
    this->runAction(actList);
}
*/
/*------------------------------------------------------------------------->
                        <-----------------------------------------------------------------------------------*/
bool FruntCell::isCellIndexEqual(CellIndex cell1,CellIndex cell2)
{
    if (cell1.columnPos==cell2.columnPos&&cell1.rowPos==cell2.rowPos) return true;
    return false;
}
void FruntCell::setNowIndex(int row,int column)
{
    nowIndex.rowPos=row;
    nowIndex.columnPos=column;
    setTag(row*7+column);
}

void FruntCell::setAnimationContig(AnimationType type, CellIndex moveTo)
{
    
    animationIterator=animationList.begin();
    AnimationStruct temp=*animationIterator;
    if (type==DeleteAnimation && temp.animationtype==DeleteAnimation) {
        CCLOG("---> Frunt [%d][%d]:Cell already have DeleteAnimation",nowIndex.rowPos,nowIndex.columnPos);
        return;
    }
    
    
    AnimationStruct animationStruct;
    switch (type) {
        case OnlyMoveAnimation:
            CCLOG("---> Frunt [%d][%d]:AnimationContig  OnlyMoveAnimation",nowIndex.rowPos,nowIndex.columnPos);
            break;
        case DeleteAnimation:
            CCLOG("---> Frunt [%d][%d]:AnimationContig  DeleteAnimation",nowIndex.rowPos,nowIndex.columnPos);
            break;
        case DropAnimation:
            CCLOG("---> Frunt [%d][%d]:AnimationContig  DropAnimation",nowIndex.rowPos,nowIndex.columnPos);
            break;
        default:
            break;
    }
    animationStruct.animationtype=type;
    animationStruct.toIndex=moveTo;
    
    animationList.push_back(animationStruct);
    _layer->shouldmoving((Layer *)this);
}

void FruntCell::showAnimation()
{
    
    animationIterator=animationList.begin();
    if (animationIterator!=animationList.end()) {
        isAnimation=true;
        AnimationStruct temp=*animationIterator;
        switch (temp.animationtype) {
            case OnlyMoveAnimation:
                movingAnimation();
                CCLOG("---> Frunt [%d][%d]:showAnimation  OnlyMoveAnimation",nowIndex.rowPos,nowIndex.columnPos);
                break;
            case DeleteAnimation:
                deleteAnimation();
                CCLOG("---> Frunt [%d][%d]:showAnimation  DeleteAnimation",nowIndex.rowPos,nowIndex.columnPos);
                break;
            case DropAnimation:
                dropAnimation();
                CCLOG("---> Frunt [%d][%d]:showAnimation  DropAnimation",nowIndex.rowPos,nowIndex.columnPos);
                break;
            default:
                break;
        }
    }else isAnimation=false;
}




void FruntCell::movingAnimation()
{
    if (isCellIndexEqual(nowIndex, toIndex)) {
        return;
    }
    _canTouch=false;
    _isMoving=true;
    _layer->moving((Layer *)this);
    
    animationIterator=animationList.begin();
    AnimationStruct temp=*animationIterator;
    double width=Director::getInstance()->getWinSize().width/7;
    double cloumnPos=width*(temp.toIndex.columnPos%7);
    double rowPos=width*temp.toIndex.rowPos;
    FiniteTimeAction *act2=MoveTo::create(0.2, Vec2(cloumnPos, rowPos));
    
    ActionInstant *act3=CallFunc::create(CC_CALLBACK_0(FruntCell::movingAnimationComplete, this));
    //create(this, callfunc_selector(FruntCell::movingAnimationComplete));
    Sequence *actList=Sequence::create(act2,act3,NULL);
    runAction(actList);
}

void FruntCell::deleteAnimation()
{
    _canTouch=false;
    _isMoving=true;
    _layer->deleteing(this);
    animationIterator=animationList.begin();
    AnimationStruct temp=*animationIterator;
    double width=Director::getInstance()->getWinSize().width/7;
    double cloumnPos=width*(temp.toIndex.columnPos%7);
    double rowPos=width*temp.toIndex.rowPos;
    if (isCellIndexEqual(nowIndex, toIndex)) {
        FiniteTimeAction *act1=Blink::create(0.2, 2);
        ActionInstant *act3=CallFunc::create(CC_CALLBACK_0(FruntCell::deleteAnimationComplete, this));
        //create(this, callfunc_selector(FruntCell::deleteAnimationComplete));
        Sequence *actList=Sequence::create(act1,act3,NULL);
        runAction(actList);
    }else
    {
        FiniteTimeAction *act1=Blink::create(0.2, 2);
        FiniteTimeAction *act2=MoveTo::create(0.2, Vec2(cloumnPos, rowPos));
        ActionInstant *act3=CallFunc::create(CC_CALLBACK_0(FruntCell::deleteAnimationComplete, this));
        //create(this, callfunc_selector(FruntCell::deleteAnimationComplete));
        Sequence *actList=Sequence::create(act1,act2,act3,NULL);
        runAction(actList);
    }
}

void FruntCell::dropAnimation()
{
    if (isCellIndexEqual(nowIndex, toIndex)) {
        return;
    }
    _canTouch=false;
    _isMoving=true;
    _layer->droping(this);
    animationIterator=animationList.begin();
    AnimationStruct temp=*animationIterator;
    double width=Director::getInstance()->getWinSize().width/7;
    double cloumnPos=width*(temp.toIndex.columnPos%7);
    double rowPos=width*temp.toIndex.rowPos;
    
    FiniteTimeAction *act2=MoveTo::create(0.2, Vec2(cloumnPos, rowPos));
    ActionInstant *act3=CallFunc::create(CC_CALLBACK_0(FruntCell::dropAnimationComplelte, this));
    //create(this, callfunc_selector(FruntCell::dropAnimationComplelte));
    Sequence *actList=Sequence::create(act2,act3,NULL);
    runAction(actList);
}

void FruntCell::movingAnimationComplete()
{
    _canTouch=true;
    _isMoving=false;
    _layer->movingComplete((Layer *)this);
    exchangeIndex();
    animationList.pop_front();
    isAnimation=false;
}
void FruntCell::deleteAnimationComplete()
{
    _isMoving=false;
    _layer->deleteComplete((Layer *)this);
    animationList.pop_front();
    isAnimation=false;
}

void FruntCell::dropAnimationComplelte()
{
    _canTouch=true;
    _isMoving=false;
    exchangeIndex();
    _layer->dropComplete((Layer *)this);
    animationList.pop_front();
    isAnimation=false;
}

void FruntCell::exchangeIndex()
{
    CellIndex temp=nowIndex;
    animationIterator=animationList.begin();
    AnimationStruct temp2=*animationIterator;
    setNowIndex(temp2.toIndex.rowPos, temp2.toIndex.columnPos);
    toIndex=temp;
}



bool FruntCell::init()
{
    if (!Layer::init()) {
        return false;
    }
    _canTouch=true;
    _isMoving=false;
    isAnimation=false;
    setTouchEnabled(true);
    _status=cellNormale;
    int temp=cellType=0;
    temp=1+std::rand()%7;
    cellType=temp;
    char pic[30]="";
    std::sprintf(pic, "fruit0%d-HD.png",cellType);
    fruntSp=Sprite::create(pic);
    this->addChild(fruntSp);
    return true;
}
/*
void FruntCell::registerWithTouchDispatcher(void)
{
    Director *pDirector=Director::getInstance();
    pDirector->getTouchDispatcher()->addTargetedDelegate(this, 0, true);
}
*/
void FruntCell::onEnter()
{
    Layer::onEnter();
    fruntSp->setPosition(Vec2(this->getContentSize().width/2, this->getContentSize().height/2));
    fruntSp->setScaleX(this->getContentSize().width/fruntSp->getContentSize().width);
    fruntSp->setScaleY(this->getContentSize().height/fruntSp->getContentSize().height);
    scheduleUpdate();
}

void FruntCell::update(float delta)
{
    if (isAnimation==false) {
        showAnimation();
    }
}


bool FruntCell::onTouchBegan(Touch *pTouch, Event *pEvent)
{
    if (!_canTouch) {
        return false;
    }
    Size tempsize = getContentSize();
    Point temppos = getPosition();
    
    Rect thispos= Rect(temppos.x, temppos.y, tempsize.width, tempsize.height);
    
    Point _p=pTouch->getLocation();
    if (_isMoving) {
        //CCLOG("ismoving");
    }else
    {
        //CCLOG("notmoving");
    }
    
    if (thispos.containsPoint(_p)&&_isMoving==false) {
        _layer->clickAtInde(getCellIndex());
        return true;
    }else
        return false;
}

void FruntCell::onTouchMoved(Touch *pTouch, Event *pEvent)
{
    
}


void FruntCell::onTouchEnded(Touch *pTouch, Event *pEvent)
{
    if (!_canTouch) {
        return;
    }
    Point _begin=pTouch->getStartLocation();
    Point _pos=pTouch->getLocation();
    _layer->direction(computeDirection(_begin, _pos));
}


MoveDirection FruntCell::computeDirection(Point p1,Point p2)
{
    double _xDir=p1.x-p2.x;
    double _yDir=p1.y-p2.y;
    Size size = Director::getInstance()->getWinSize();
    float winw = size.width;
    if (_xDir>10&&fabs(_yDir)<winw/7) {
        return LEFT;
    }else if (_yDir>10&&fabs(_xDir)<winw/7)
    {
        return DOWN;
    }else if (_xDir<-10&&fabs(_yDir)<winw/7)
    {
        return RIGHT;
    }else if (_yDir<-10&&fabs(_xDir)<winw/7)
        return UP;
    return NONE;
}



void FruntCell::registDelegate(ClickDelegate *layer)
{
    _layer=layer;
}

void FruntCell::setCellStatus(CellStatus status)
{
    changeStauts(status);
}
CellStatus FruntCell::getCellStatus()
{
    return _status;
}

CellIndex FruntCell::getCellIndex()
{
    return nowIndex;
}
CellIndex FruntCell::getToCellIndex()
{
    return toIndex;
}
CellIndex FruntCell::getCellTempIndex()
{
    return _tempIndex;
}

void FruntCell::changePos(FruntCell *cell)
{
    
}

void FruntCell::changeStauts(CellStatus status)
{
    if (status==cellNormale) {
        spNormal();
    }
    if (status==cellHeightLight) {
        spheightLight();
    }
    if (status==cellDestory) {
        spDestory();
    }
}



void FruntCell::spDestory()
{
    _status=cellDestory;
}

void FruntCell::spNormal()
{
    _status=cellNormale;
}

void FruntCell::spheightLight()
{
    _status=cellHeightLight;
}
