//
//  FruntCell.h
//  FruitEat
//
//  Created by eisoo on 14-3-31.
//
//

#ifndef __FruitEat__FruntCell__
#define __FruitEat__FruntCell__

#include <iostream>

#include "help.h"
#include "ClickDelegate.h"
#include  <list>

#include "cocos2d.h"
using namespace cocos2d;
using namespace std;

typedef struct {
    AnimationType animationtype;
    CellIndex toIndex;
}AnimationStruct;

typedef list<AnimationStruct> AnimationList;
typedef AnimationList::iterator AnimationIterator;


class FruntCell: public Layer
{
    
private:
    
    Sprite *fruntSp;
    CellIndex _index;
    CellIndex _movingIndex;
    CellIndex _tempIndex;
    void spheightLight();
    void spNormal();
    void spDestory();
    CellStatus _status;
    void changeStauts(CellStatus status);
    ClickDelegate *_layer;
    MoveDirection computeDirection(Point p1,Point p2);
    void movingComplete();
    void exchangeComplete();
    void deleteComplete();
    void dropComplete();
    void searchNearCells();
    bool _topH;
    bool _leftH;
    bool _rightH;
    bool _bottomH;
public:
    //new
    AnimationList animationList;
    AnimationIterator animationIterator;
    
    bool isCellIndexEqual(CellIndex cell1,CellIndex cell2);

    CellIndex nowIndex;
    CellIndex toIndex;
    
    void setNowIndex(int row,int column);
    void setAnimationContig(AnimationType type, CellIndex moveTo);
    void showAnimation();
    void movingAnimation();
    void deleteAnimation();
    void dropAnimation();
    void movingAnimationComplete();
    void deleteAnimationComplete();
    void dropAnimationComplelte();
    
    void exchangeIndex();
    CellIndex getCellIndex();
    CellIndex getToCellIndex();
    
    void checkAnimation();
    bool isAnimation;
    virtual void update(float delta);
    
    
    
    
    
    
    //old
    unsigned cellType;//1,2...9
    
    CellIndex getCellTempIndex();
    CellStatus getCellStatus();
    
    
    
    
    bool _isDrop;
    bool _isDeleteing;
    bool _isMoving;
    bool _canTouch;
    
    void setIndex(int column,int row);
    void setTempIndex(int column,int row);
    
    void setMoveToIndex(int column,int row);
    void setDropToIndex(int column,int row);
    void resetMoveToIndex();
    void registDelegate(ClickDelegate *layer);
    void setCellStatus(CellStatus status);
    
    void changePos(FruntCell *cell);
    CREATE_FUNC(FruntCell);
    //virtual void registerWithTouchDispatcher(void);
    virtual bool init();
    virtual void onEnter();
    virtual bool onTouchBegan(Touch *pTouch, Event *pEvent);
    virtual void onTouchMoved(Touch *pTouch, Event *pEvent);
    virtual void onTouchEnded(Touch *pTouch, Event *pEvent);
    
};


#endif /* defined(__FruitEat__FruntCell__) */
