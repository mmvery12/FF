//
//  MainACT.h
//  FishingEat
//
//  Created by eisoo on 14-2-14.
//
//

#ifndef __FishingEat__GameACT__
#define __FishingEat__GameACT__


#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include <list>
#include <deque>
#include <map>
#include <pthread.h>


#include "SceneManager.h"
#include "define.h"
#include "Category.h"
#include "FruntCell.h"
#include "help.h"
#include "ClickDelegate.h"
#include "define.h"
#include "cocos2d.h"
using namespace cocos2d;
using std::string;
using namespace std;

//typedef list<int> DropQueue;
//typedef DropQueue::iterator DropQueueIterator;
typedef int _MAX_ROW;
typedef int _BEGIN_ROW;
typedef int _END_ROW;
typedef int _DROPLENGTH;
typedef map<_BEGIN_ROW,_END_ROW> DropRange;
typedef DropRange::iterator RangeIterator;
typedef map<DropRange ,_DROPLENGTH> DropSubMap;
typedef DropSubMap::iterator SubMapIterator;
typedef map<_MAX_ROW,DropSubMap> DropMap;
typedef DropMap::iterator MapIterator;
typedef list<DropMap> DropList;
typedef DropList::iterator ListIterator;
typedef deque<DropList> Dropdeque;
typedef Dropdeque::iterator DequeIterator;



namespace Game {
	
    static void *thr_fun(void *arge);
    void recuse(DeleteIterator it,DropMap *map,pair<DeleteIterator, DeleteIterator> Findpair,int topIndex);
    
    class GameLayer : public Layer,ClickDelegate{
        
        GameLayer();
		virtual ~GameLayer();
        void showTag();
    public:
        /*
         -1     NULL
         0      normal
         1      canramoved
         2      moving
         3      droping
         4      deleteing
         */
        int cellsStatus[14][7];
        int dropTopIndex[7];
        int animationColumns[7];
        
        struct CmpByValue {
            bool operator()(const PAIR& lhs, const PAIR& rhs) {
                return lhs.second >= rhs.second;
            }
        };
        
        Dropdeque dropqdeque;
        DequeIterator dropqdequeIterator;
    
        bool haveDestory;
        void TODO_deleteCell();
        void TODO_resetCell();
        void TODO_dropCell(DropSubMap submap,int column);
        void timeCallBack();
        Deletemultimap find();
        void showCellAnimation();
        void checkColumnHaveAnimation();
        void destory();
    private:
		Category *cy;
		FruntCell *_tempCell1;
		FruntCell *_tempCell2;
        CellIndex _lastedClick;
        void compute(MoveDirection dir);
        void registTwoCell(CellIndex c1,CellIndex c2);
        void resetTwoCellPos();
        void addNewCells(int column);
        FruntCell * randNewCell(int columnPos,int rowPos,bool isPlaying);
        
        Node *getLiveCell(CellIndex index);
        ProgressTimer *progress;
        float dtf;
        void pop(Ref *node);
        
    public:
        
        static Scene *createGameACTScene(void);
        virtual bool init();
        virtual void onEnter();
        virtual void update(float delta);
        CREATE_FUNC(GameLayer);
        //override for register one point touch
        //virtual void registerWithTouchDispatcher(void);
        //cctouch delegate
        virtual bool onTouchBegan(Touch *pTouch, Event *pEvent);
        virtual void onTouchMoved(Touch *pTouch, Event *pEvent);
        virtual void onTouchEnded(Touch *pTouch, Event *pEvent);
        
        //click delegate
        virtual void clickAtInde(CellIndex index);
        virtual void direction(MoveDirection dir);
        
        virtual void shouldmoving(Layer *cell);
        virtual void moving(Layer *cell);
        virtual void deleteing(Layer *cell);
        virtual void droping(Layer *cell);
        
        virtual void deleteComplete(Layer *cell);
        virtual void movingComplete(Layer *cell);
        virtual void dropComplete(Layer *cell);
    };
}
    
    

#endif /* defined(__FishingEat__GameACT__) */
