//
//  ClickDelegate.h
//  FruitEat
//
//  Created by eisoo on 14-3-31.
//
//

#ifndef __FruitEat__ClickDelegate__
#define __FruitEat__ClickDelegate__

#include <iostream>
#include "help.h"
#include "cocos2d.h"
using namespace cocos2d;
class ClickDelegate
{
public:
    ClickDelegate();
    ~ClickDelegate();
    virtual void clickAtInde(CellIndex index)=0;
    virtual void direction(MoveDirection dir)=0;
    
    virtual void shouldmoving(Layer *cell)=0;
    virtual void moving(Layer *cell)=0;
    virtual void droping(Layer *cell)=0;
    virtual void deleteing(Layer *cell)=0;
    
    virtual void deleteComplete(Layer *cell)=0;
    virtual void movingComplete(Layer *cell)=0;

    virtual void dropComplete(Layer *cell)=0;
    //    virtual void exchangeComplete(CCLayer *cell);
};
#endif /* defined(__FruitEat__ClickDelegate__) */
