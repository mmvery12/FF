//
//  ClickDelegate.cpp
//  FruitEat
//
//  Created by eisoo on 14-3-31.
//
//

#include "ClickDelegate.h"
ClickDelegate::ClickDelegate()
{
    
}
ClickDelegate::~ClickDelegate()
{
    
}

//void ClickDelegate::clickAtInde(CellIndex index)
//{
//    
//}
//void ClickDelegate::direction(MoveDirection dir)
//{
//    
//}
//void ClickDelegate::shouldmoving(CCLayer *cell)
//{
//
//}
//void ClickDelegate::moving(CCLayer *cell)
//{
//    
//}
//void ClickDelegate::droping(CCLayer *cell)
//{
//    
//}
//void ClickDelegate::movingComplete(CCLayer *cell)
//{
//    
//}
//void ClickDelegate::exchangeComplete(CCLayer *cell)
//{
//    
//}
//void ClickDelegate::deleteComplete(CCLayer *cell)
//{
//    
//}
//void ClickDelegate::dropComplete(CCLayer *cell)
//{
//    
//}
///////////